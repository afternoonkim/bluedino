import type { Metadata } from "next";
import SalaryNetCalculatorClient from "./SalaryNetCalculatorClient";

export const metadata: Metadata = {
  title: "연봉 실수령액 계산기 | 세후 월급 계산 | BlueDino",
  description:
    "연봉을 입력하면 세금과 4대 보험을 제외한 실제 실수령액을 계산할 수 있는 연봉 실수령액 계산기입니다. 월 실수령액과 연간 공제액을 한눈에 확인할 수 있습니다.",
  keywords: ["연봉 실수령액 계산기",
    "세후 월급 계산기",
    "월급 실수령액 계산",
    "salary calculator",
    "연봉 계산기",
    "BlueDino"],
  alternates: {
    canonical: "/cal/salary-net",
  },
  openGraph: {
    title: "연봉 실수령액 계산기 | 세후 월급 계산 | BlueDino",
    description:
      "연봉을 입력하면 세금과 4대 보험을 제외한 실제 실수령액을 계산할 수 있는 연봉 실수령액 계산기입니다. 월 실수령액과 연간 공제액을 한눈에 확인할 수 있습니다.",
    url: "https://bluedino.kr/cal/salary-net",
    siteName: "BlueDino",
    type: "website",
    locale: "ko_KR",
  },
  twitter: {
    card: "summary_large_image",
    title: "연봉 실수령액 계산기 | 세후 월급 계산 | BlueDino",
    description:
      "연봉을 입력하면 세금과 4대 보험을 제외한 실제 실수령액을 계산할 수 있는 연봉 실수령액 계산기입니다. 월 실수령액과 연간 공제액을 한눈에 확인할 수 있습니다.",
  },
};

export default function Page() {
  return <SalaryNetCalculatorClient />;
}
